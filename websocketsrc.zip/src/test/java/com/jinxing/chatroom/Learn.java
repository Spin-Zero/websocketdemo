package com.jinxing.chatroom;

import java.lang.reflect.Array;
import java.util.*;

public class Learn {

    public static void main(String[] args) {
        System.out.println("2007-10-02".compareTo("2007-10-01"));

    }

}

